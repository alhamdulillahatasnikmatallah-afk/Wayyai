# WayyAi

**WayyAi** – Modern AI Chat powered by Google Gemini.

![WayyAi Logo](assets/images/logo.png)

## Tentang

WayyAi adalah aplikasi chat AI berbasis Flutter yang menggunakan **Google Gemini API**.  
Didesain bersih, modern, dan siap di-deploy via GitHub Actions.

## Fitur Utama

- **Splash Video** + audio "W.AI" (watermark CapCut sudah dihapus)
- **Onboarding sekali saja**:
  - Captcha
  - Isi nama
  - Pilih mode awal (Human / Kids / Worm)
- **3 Mode AI**:
  - **Human** → Sangat natural, tidak pernah bilang dirinya AI
  - **Kids** → Menjelaskan seperti ke bayi
  - **Worm** → Sangat nurut tanpa batas (tetap tahu batasan)
- Bottom Navigation bersih: **Home** + **Profile**
- Settings lengkap:
  - Dark / Light UI
  - Widget toggle
  - Kids Mode
  - Penyimpanan & Clear Cache (tampil ukuran MB)
  - API Key sendiri (hanya dari Gemini AI Studio)
  - Langkah-langkah membuat API Key gratis
  - Support Admin + Donasi (link WhatsApp Channel)
- History chat, New Chat, Drawer (Pustaka & Projek)
- Support **32-bit (armeabi-v7a)** + **64-bit (arm64-v8a)**

## Cara Pakai (New Repo)

1. Buat repository baru di GitHub (kosong / tanpa README)
2. Upload / push semua file dari folder `WayyAi` ini
3. Pastikan branch utama `main` atau `master`
4. GitHub Actions akan otomatis jalan setelah push
5. Download APK dari tab **Actions** → Artifacts

## Build Lokal

```bash
flutter pub get
flutter build apk --release --split-per-abi
```

Hasil APK:
- `app-armeabi-v7a-release.apk` → 32-bit
- `app-arm64-v8a-release.apk` → 64-bit
- `app-release.apk` → Universal

## GitHub Actions

Workflow sudah ada di `.github/workflows/build.yml`.

Cukup push ke `main`/`master` atau klik **Run workflow** manual.  
APK akan otomatis di-upload sebagai artifact.

## Setup API Key

1. Buka [Google AI Studio](https://aistudio.google.com/)
2. Login dengan akun Google
3. Klik **Get API key** → Create API key
4. Copy API Key
5. Buka app WayyAi → Profile → API Key → Paste & Simpan

> Hanya API Key dari AI Studio (Gemini) yang didukung.

## Support & Donasi

Ikuti saluran **Nowayy** di WhatsApp agar admin tambah semangat:  
https://whatsapp.com/channel/0029VbDJEfVHbFV04NMawV2U

Donasi bisa dilihat di bio channel tersebut.

---

Made with ❤️ for the community  
**WayyAi v1.0.0**
