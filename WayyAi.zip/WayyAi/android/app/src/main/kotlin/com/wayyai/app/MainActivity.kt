package com.wayyai.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
