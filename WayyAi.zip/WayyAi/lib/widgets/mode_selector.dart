import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/settings_service.dart';

class ModeSelector extends StatelessWidget {
  const ModeSelector({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = Provider.of<SettingsService>(context);
    return PopupMenuButton<String>(
      tooltip: 'Pilih Mode',
      icon: const Icon(Icons.tune),
      onSelected: (value) => settings.setMode(value),
      itemBuilder: (context) => [
        PopupMenuItem(
          value: 'human',
          child: Row(
            children: [
              Icon(Icons.person, color: settings.mode == 'human' ? Theme.of(context).primaryColor : null),
              const SizedBox(width: 8),
              const Text('Human'),
              if (settings.mode == 'human') ...[const Spacer(), const Icon(Icons.check, size: 18)],
            ],
          ),
        ),
        PopupMenuItem(
          value: 'kids',
          child: Row(
            children: [
              Icon(Icons.child_care, color: settings.mode == 'kids' ? Theme.of(context).primaryColor : null),
              const SizedBox(width: 8),
              const Text('Kids'),
              if (settings.mode == 'kids') ...[const Spacer(), const Icon(Icons.check, size: 18)],
            ],
          ),
        ),
        PopupMenuItem(
          value: 'worm',
          child: Row(
            children: [
              Icon(Icons.pets, color: settings.mode == 'worm' ? Theme.of(context).primaryColor : null),
              const SizedBox(width: 8),
              const Text('Worm'),
              if (settings.mode == 'worm') ...[const Spacer(), const Icon(Icons.check, size: 18)],
            ],
          ),
        ),
      ],
    );
  }
}
