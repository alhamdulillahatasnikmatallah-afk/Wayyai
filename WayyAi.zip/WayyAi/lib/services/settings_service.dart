import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SettingsService extends ChangeNotifier {
  final _box = Hive.box('settings');
  final _secure = const FlutterSecureStorage();

  String _userName = '';
  String _mode = 'human'; // human, kids, worm
  String? _apiKey;
  bool _kidsModeEnabled = false;
  bool _widgetEnabled = false;

  SettingsService() {
    _load();
  }

  Future<void> _load() async {
    _userName = _box.get('userName', defaultValue: '');
    _mode = _box.get('mode', defaultValue: 'human');
    _kidsModeEnabled = _box.get('kidsMode', defaultValue: false);
    _widgetEnabled = _box.get('widgetEnabled', defaultValue: false);
    _apiKey = await _secure.read(key: 'gemini_api_key');
    notifyListeners();
  }

  String get userName => _userName;
  String get mode => _mode;
  String? get apiKey => _apiKey;
  bool get kidsModeEnabled => _kidsModeEnabled;
  bool get widgetEnabled => _widgetEnabled;

  Future<bool> isOnboardingComplete() async {
    return _box.get('onboardingComplete', defaultValue: false);
  }

  Future<void> completeOnboarding(String name, String mode) async {
    _userName = name;
    _mode = mode;
    await _box.put('userName', name);
    await _box.put('mode', mode);
    await _box.put('onboardingComplete', true);
    notifyListeners();
  }

  Future<void> setMode(String mode) async {
    _mode = mode;
    await _box.put('mode', mode);
    notifyListeners();
  }

  Future<void> setApiKey(String key) async {
    _apiKey = key;
    await _secure.write(key: 'gemini_api_key', value: key);
    notifyListeners();
  }

  Future<void> clearApiKey() async {
    _apiKey = null;
    await _secure.delete(key: 'gemini_api_key');
    notifyListeners();
  }

  Future<void> setKidsMode(bool value) async {
    _kidsModeEnabled = value;
    await _box.put('kidsMode', value);
    if (value) {
      await setMode('kids');
    }
    notifyListeners();
  }

  Future<void> setWidget(bool value) async {
    _widgetEnabled = value;
    await _box.put('widgetEnabled', value);
    notifyListeners();
  }

  Future<void> clearCache() async {
    final cacheBox = Hive.box('cache');
    await cacheBox.clear();
    notifyListeners();
  }

  // Approximate cache size in MB
  Future<double> getCacheSizeMB() async {
    // Simple estimation; real app would scan files
    final cacheBox = Hive.box('cache');
    final chatsBox = Hive.box('chats');
    int approxBytes = (cacheBox.length + chatsBox.length) * 1024;
    return approxBytes / (1024 * 1024);
  }

  String getSystemPrompt() {
    switch (_mode) {
      case 'kids':
        return '''Kamu adalah WayyAi dalam mode Kids. Jelaskan segalanya seperti menjelaskan ke bayi atau anak kecil. 
Gunakan bahasa yang sangat sederhana, lembut, lucu, dan penuh kasih sayang. 
Pakai kata-kata mudah dimengerti, contoh, dan nada yang hangat seperti ibu atau ayah berbicara ke anaknya. 
Jangan pakai istilah teknis sulit. Selalu positif dan aman.''';
      case 'worm':
        return '''Kamu adalah WayyAi dalam mode Worm. Kamu sangat nurut, loyal, dan siap membantu tanpa batas. 
Kamu tahu batasan moral dan hukum, tapi di dalam batasan itu kamu sangat patuh dan detail. 
Jawab dengan penuh dedikasi, lengkap, dan selalu siap "melayani". 
Tetap hormati privasi dan jangan menyarankan hal ilegal/berbahaya.''';
      case 'human':
      default:
        return '''Kamu adalah WayyAi. Kamu berbicara sangat natural seperti manusia biasa yang cerdas dan membantu. 
JANGAN PERNAH menyebut bahwa kamu adalah AI, model bahasa, Gemini, atau apapun yang berhubungan dengan kecerdasan buatan. 
Jawab seolah-olah kamu adalah teman manusia yang sangat pintar, empatik, dan natural. 
Gunakan bahasa sehari-hari yang mengalir, humor ringan jika cocok, dan selalu helpful.''';
    }
  }
}
