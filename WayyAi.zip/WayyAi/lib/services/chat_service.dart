import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

class ChatMessage {
  final String id;
  final String role; // user / model
  final String content;
  final DateTime timestamp;
  final String? imagePath;

  ChatMessage({
    required this.id,
    required this.role,
    required this.content,
    required this.timestamp,
    this.imagePath,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'role': role,
        'content': content,
        'timestamp': timestamp.toIso8601String(),
        'imagePath': imagePath,
      };

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
        id: json['id'],
        role: json['role'],
        content: json['content'],
        timestamp: DateTime.parse(json['timestamp']),
        imagePath: json['imagePath'],
      );
}

class ChatSession {
  final String id;
  String title;
  List<ChatMessage> messages;
  final DateTime createdAt;
  DateTime updatedAt;
  String mode;

  ChatSession({
    required this.id,
    required this.title,
    required this.messages,
    required this.createdAt,
    required this.updatedAt,
    this.mode = 'human',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'messages': messages.map((m) => m.toJson()).toList(),
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'mode': mode,
      };

  factory ChatSession.fromJson(Map<String, dynamic> json) => ChatSession(
        id: json['id'],
        title: json['title'],
        messages: (json['messages'] as List).map((m) => ChatMessage.fromJson(Map<String, dynamic>.from(m))).toList(),
        createdAt: DateTime.parse(json['createdAt']),
        updatedAt: DateTime.parse(json['updatedAt']),
        mode: json['mode'] ?? 'human',
      );
}

class ChatService extends ChangeNotifier {
  final _box = Hive.box('chats');
  final _uuid = const Uuid();
  List<ChatSession> _sessions = [];
  String? _currentSessionId;

  ChatService() {
    _load();
  }

  List<ChatSession> get sessions => List.unmodifiable(_sessions);
  String? get currentSessionId => _currentSessionId;

  ChatSession? get currentSession {
    if (_currentSessionId == null) return null;
    try {
      return _sessions.firstWhere((s) => s.id == _currentSessionId);
    } catch (_) {
      return null;
    }
  }

  void _load() {
    final data = _box.get('sessions');
    if (data != null) {
      _sessions = (data as List).map((e) => ChatSession.fromJson(Map<String, dynamic>.from(e))).toList();
      _sessions.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    }
    notifyListeners();
  }

  Future<void> _save() async {
    await _box.put('sessions', _sessions.map((s) => s.toJson()).toList());
  }

  Future<ChatSession> createNewSession({String mode = 'human'}) async {
    final session = ChatSession(
      id: _uuid.v4(),
      title: 'Obrolan Baru',
      messages: [],
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      mode: mode,
    );
    _sessions.insert(0, session);
    _currentSessionId = session.id;
    await _save();
    notifyListeners();
    return session;
  }

  void setCurrentSession(String id) {
    _currentSessionId = id;
    notifyListeners();
  }

  Future<void> addMessage(String role, String content, {String? imagePath}) async {
    if (_currentSessionId == null) {
      await createNewSession();
    }
    final session = currentSession!;
    final msg = ChatMessage(
      id: _uuid.v4(),
      role: role,
      content: content,
      timestamp: DateTime.now(),
      imagePath: imagePath,
    );
    session.messages.add(msg);
    session.updatedAt = DateTime.now();
    if (session.messages.length == 1 && role == 'user') {
      session.title = content.length > 40 ? '${content.substring(0, 40)}...' : content;
    }
    await _save();
    notifyListeners();
  }

  List<Content> getHistoryForGemini() {
    final session = currentSession;
    if (session == null) return [];
    return session.messages
        .map((m) => Content(m.role == 'user' ? 'user' : 'model', [TextPart(m.content)]))
        .toList();
  }

  Future<void> deleteSession(String id) async {
    _sessions.removeWhere((s) => s.id == id);
    if (_currentSessionId == id) _currentSessionId = null;
    await _save();
    notifyListeners();
  }

  Future<void> clearAll() async {
    _sessions.clear();
    _currentSessionId = null;
    await _box.clear();
    notifyListeners();
  }

  List<ChatSession> get recentSessions => _sessions.take(20).toList();
}
