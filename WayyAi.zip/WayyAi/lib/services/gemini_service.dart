import 'package:flutter/foundation.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'settings_service.dart';

class GeminiService extends ChangeNotifier {
  GenerativeModel? _model;
  String? _lastError;

  String? get lastError => _lastError;

  Future<void> init(SettingsService settings) async {
    final key = settings.apiKey;
    if (key == null || key.isEmpty) {
      _model = null;
      return;
    }
    try {
      _model = GenerativeModel(
        model: 'gemini-1.5-flash',
        apiKey: key,
        systemInstruction: Content.system(settings.getSystemPrompt()),
        generationConfig: GenerationConfig(
          temperature: settings.mode == 'worm' ? 0.9 : 0.7,
          maxOutputTokens: 2048,
        ),
      );
      _lastError = null;
    } catch (e) {
      _lastError = e.toString();
      _model = null;
    }
    notifyListeners();
  }

  Future<String> chat(String message, List<Content> history, SettingsService settings) async {
    if (_model == null) {
      await init(settings);
    }
    if (_model == null) {
      return '⚠️ API Key belum diatur. Silakan masuk ke Settings → API Key untuk menambahkan Gemini API Key dari AI Studio.';
    }

    try {
      // Re-init with latest system prompt if mode changed
      _model = GenerativeModel(
        model: 'gemini-1.5-flash',
        apiKey: settings.apiKey!,
        systemInstruction: Content.system(settings.getSystemPrompt()),
        generationConfig: GenerationConfig(
          temperature: settings.mode == 'worm' ? 0.95 : (settings.mode == 'kids' ? 0.6 : 0.75),
          maxOutputTokens: 2048,
        ),
      );

      final chat = _model!.startChat(history: history);
      final response = await chat.sendMessage(Content.text(message));
      return response.text ?? 'Tidak ada respons.';
    } catch (e) {
      _lastError = e.toString();
      if (e.toString().contains('API_KEY_INVALID') || e.toString().contains('401')) {
        return '❌ API Key tidak valid. Silakan periksa kembali di Settings.';
      }
      return 'Terjadi kesalahan: ${e.toString()}';
    }
  }

  bool get isReady => _model != null;
}
