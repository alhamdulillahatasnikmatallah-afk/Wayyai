import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/theme_service.dart';
import '../services/settings_service.dart';
import '../services/chat_service.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = Provider.of<SettingsService>(context);
    final theme = Provider.of<ThemeService>(context);
    final isDark = theme.isDark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile & Settings'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Profile header
          Center(
            child: Column(
              children: [
                CircleAvatar(
                  radius: 48,
                  backgroundColor: Colors.grey[800],
                  backgroundImage: const AssetImage('assets/images/profile_placeholder.jpg'),
                ),
                const SizedBox(height: 12),
                Text(
                  settings.userName.isEmpty ? 'Pengguna WayyAi' : settings.userName,
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                Text(
                  'Mode: ${_modeLabel(settings.mode)}',
                  style: TextStyle(color: Colors.grey[600]),
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),

          // Theme
          _sectionTitle('Tampilan'),
          SwitchListTile(
            title: const Text('Dark Mode'),
            subtitle: Text(isDark ? 'UI Gelap' : 'UI Terang'),
            value: isDark,
            onChanged: (v) => theme.setDark(v),
            secondary: Icon(isDark ? Icons.dark_mode : Icons.light_mode),
          ),

          const Divider(),

          // Widget
          _sectionTitle('Widget'),
          SwitchListTile(
            title: const Text('Widget'),
            subtitle: const Text('Aktifkan widget di home screen (experimental)'),
            value: settings.widgetEnabled,
            onChanged: (v) => settings.setWidget(v),
            secondary: const Icon(Icons.widgets_outlined),
          ),

          const Divider(),

          // Kids Mode
          _sectionTitle('Kids Mode'),
          SwitchListTile(
            title: const Text('Kids Mode'),
            subtitle: const Text('Paksa mode penjelasan seperti ke bayi'),
            value: settings.kidsModeEnabled,
            onChanged: (v) => settings.setKidsMode(v),
            secondary: const Icon(Icons.child_care),
          ),

          const Divider(),

          // Storage
          _sectionTitle('Penyimpanan'),
          FutureBuilder<double>(
            future: settings.getCacheSizeMB(),
            builder: (context, snap) {
              final size = snap.data ?? 0.0;
              return ListTile(
                leading: const Icon(Icons.storage),
                title: const Text('Cache & Data'),
                subtitle: Text('${size.toStringAsFixed(2)} MB terpakai'),
                trailing: TextButton(
                  onPressed: () async {
                    final confirm = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Hapus Cache?'),
                        content: const Text('Semua riwayat chat dan cache akan dihapus. Lanjutkan?'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
                          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus')),
                        ],
                      ),
                    );
                    if (confirm == true) {
                      await settings.clearCache();
                      await Provider.of<ChatService>(context, listen: false).clearAll();
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Cache berhasil dibersihkan')),
                        );
                      }
                    }
                  },
                  child: const Text('Bersihkan'),
                ),
              );
            },
          ),

          const Divider(),

          // API Key
          _sectionTitle('API Key (Gemini AI Studio)'),
          ListTile(
            leading: const Icon(Icons.key),
            title: Text(settings.apiKey == null ? 'Belum diatur' : 'API Key sudah diset'),
            subtitle: const Text('Wajib dari Google AI Studio'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showApiKeyDialog(context, settings),
          ),
          ListTile(
            leading: const Icon(Icons.help_outline),
            title: const Text('Cara membuat API Key gratis'),
            onTap: () => _showApiSteps(context),
          ),

          const Divider(),

          // Support & Donate
          _sectionTitle('Support & Donasi'),
          ListTile(
            leading: const Icon(Icons.support_agent),
            title: const Text('Support for Admin'),
            subtitle: const Text('Ikuti saluran WhatsApp agar admin tambah semangat'),
            onTap: () => launchUrl(Uri.parse('https://whatsapp.com/channel/0029VbDJEfVHbFV04NMawV2U')),
          ),
          ListTile(
            leading: const Icon(Icons.favorite, color: Colors.red),
            title: const Text('Donasi'),
            subtitle: const Text('Dukung pengembangan WayyAi (lihat bio channel)'),
            onTap: () => launchUrl(Uri.parse('https://whatsapp.com/channel/0029VbDJEfVHbFV04NMawV2U')),
          ),

          const SizedBox(height: 24),
          Center(
            child: Text(
              'WayyAi v1.0.0\nPowered by Gemini',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey[600], fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  String _modeLabel(String mode) {
    switch (mode) {
      case 'kids':
        return 'Kids';
      case 'worm':
        return 'Worm';
      default:
        return 'Human';
    }
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 4),
      child: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.grey),
      ),
    );
  }

  void _showApiKeyDialog(BuildContext context, SettingsService settings) {
    final controller = TextEditingController(text: settings.apiKey ?? '');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Gemini API Key'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Hanya API Key dari Google AI Studio yang didukung.',
              style: TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'API Key',
                border: OutlineInputBorder(),
                hintText: 'AIza...',
              ),
            ),
          ],
        ),
        actions: [
          if (settings.apiKey != null)
            TextButton(
              onPressed: () async {
                await settings.clearApiKey();
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('Hapus', style: TextStyle(color: Colors.red)),
            ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () async {
              final key = controller.text.trim();
              if (key.isNotEmpty) {
                await settings.setApiKey(key);
                if (ctx.mounted) {
                  Navigator.pop(ctx);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('API Key berhasil disimpan')),
                  );
                }
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _showApiSteps(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.7,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        builder: (_, scroll) => SingleChildScrollView(
          controller: scroll,
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[400],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Langkah-langkah membuat API Key gratis',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              _step(1, 'Buka web Google AI Studio', 'https://aistudio.google.com/'),
              _step(2, 'Login dengan akun Google kamu'),
              _step(3, 'Klik tombol "Get API key" di pojok kiri atas / menu'),
              _step(4, 'Pilih "Create API key in new project" atau project yang sudah ada'),
              _step(5, 'Salin (copy) API Key yang muncul (biasanya diawali AIza...)'),
              _step(6, 'Kembali ke WayyAi → Profile → API Key → tempel & simpan'),
              _step(7, 'Selesai! Sekarang kamu bisa chat dengan WayyAi'),
              const SizedBox(height: 16),
              const Text(
                'Catatan:\n• API Key gratis punya kuota terbatas (cukup untuk penggunaan pribadi).\n• Jangan bagikan API Key ke siapapun.\n• Hanya API dari AI Studio / Gemini yang didukung.',
                style: TextStyle(fontSize: 13, color: Colors.grey),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => launchUrl(Uri.parse('https://aistudio.google.com/')),
                  child: const Text('Buka AI Studio'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _step(int num, String text, [String? link]) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 12,
            backgroundColor: Colors.blue,
            child: Text('$num', style: const TextStyle(color: Colors.white, fontSize: 12)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(text),
                if (link != null)
                  GestureDetector(
                    onTap: () => launchUrl(Uri.parse(link)),
                    child: Text(link, style: const TextStyle(color: Colors.blue, fontSize: 12)),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
