import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/settings_service.dart';
import 'main_nav.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _nameController = TextEditingController();
  final _captchaController = TextEditingController();
  String _selectedMode = 'human';
  int _step = 0; // 0=captcha, 1=name, 2=mode
  late String _captchaCode;
  final _random = Random();

  @override
  void initState() {
    super.initState();
    _generateCaptcha();
  }

  void _generateCaptcha() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    _captchaCode = List.generate(5, (_) => chars[_random.nextInt(chars.length)]).join();
  }

  void _next() {
    if (_step == 0) {
      if (_captchaController.text.toUpperCase() != _captchaCode) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Captcha salah, coba lagi')),
        );
        _generateCaptcha();
        _captchaController.clear();
        setState(() {});
        return;
      }
    } else if (_step == 1) {
      if (_nameController.text.trim().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Nama tidak boleh kosong')),
        );
        return;
      }
    }
    if (_step < 2) {
      setState(() => _step++);
    } else {
      _finish();
    }
  }

  Future<void> _finish() async {
    final settings = Provider.of<SettingsService>(context, listen: false);
    await settings.completeOnboarding(_nameController.text.trim(), _selectedMode);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const MainNav()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 40),
              Image.asset('assets/images/logo.png', height: 80),
              const SizedBox(height: 16),
              Text(
                'Selamat datang di WayyAi',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                'Integrasi sekali saja setelah download',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey[600]),
              ),
              const SizedBox(height: 40),
              if (_step == 0) ...[
                const Text('Verifikasi Captcha', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18)),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                  decoration: BoxDecoration(
                    color: isDark ? Colors.grey[900] : Colors.grey[200],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    _captchaCode,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 8,
                      color: isDark ? Colors.white : Colors.black87,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _captchaController,
                  textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(
                    labelText: 'Masukkan kode di atas',
                    border: OutlineInputBorder(),
                  ),
                ),
              ] else if (_step == 1) ...[
                const Text('Siapa nama kamu?', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18)),
                const SizedBox(height: 16),
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nama panggilan',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.person),
                  ),
                ),
              ] else ...[
                const Text('Pilih Mode Awal', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18)),
                const SizedBox(height: 8),
                const Text('Bisa diganti kapan saja di Home', style: TextStyle(color: Colors.grey)),
                const SizedBox(height: 20),
                _modeCard('human', 'Human', 'Sangat natural, seperti manusia biasa. Tidak ada kata AI sama sekali.', Icons.person),
                const SizedBox(height: 12),
                _modeCard('kids', 'Kids', 'Menjelaskan seperti ke bayi. Bahasa lembut & sederhana.', Icons.child_care),
                const SizedBox(height: 12),
                _modeCard('worm', 'Worm', 'Sangat nurut tanpa batas (tapi tetap tahu batasan).', Icons.pets),
              ],
              const Spacer(),
              ElevatedButton(
                onPressed: _next,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: Text(_step == 2 ? 'Mulai WayyAi' : 'Lanjut'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _modeCard(String value, String title, String desc, IconData icon) {
    final selected = _selectedMode == value;
    return InkWell(
      onTap: () => setState(() => _selectedMode = value),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(
            color: selected ? Theme.of(context).primaryColor : Colors.grey.shade400,
            width: selected ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(12),
          color: selected ? Theme.of(context).primaryColor.withOpacity(0.1) : null,
        ),
        child: Row(
          children: [
            Icon(icon, color: selected ? Theme.of(context).primaryColor : Colors.grey),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(desc, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                ],
              ),
            ),
            if (selected) Icon(Icons.check_circle, color: Theme.of(context).primaryColor),
          ],
        ),
      ),
    );
  }
}
