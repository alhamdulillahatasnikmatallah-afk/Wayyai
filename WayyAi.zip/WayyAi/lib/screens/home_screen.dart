import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import '../services/chat_service.dart';
import '../services/gemini_service.dart';
import '../services/settings_service.dart';
import '../widgets/mode_selector.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  bool _isLoading = false;
  bool _showDrawer = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final chat = Provider.of<ChatService>(context, listen: false);
      if (chat.currentSession == null && chat.sessions.isEmpty) {
        chat.createNewSession();
      } else if (chat.currentSession == null && chat.sessions.isNotEmpty) {
        chat.setCurrentSession(chat.sessions.first.id);
      }
    });
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _isLoading) return;

    final chat = Provider.of<ChatService>(context, listen: false);
    final gemini = Provider.of<GeminiService>(context, listen: false);
    final settings = Provider.of<SettingsService>(context, listen: false);

    _controller.clear();
    setState(() => _isLoading = true);

    await chat.addMessage('user', text);
    _scrollToBottom();

    final history = chat.getHistoryForGemini();
    // Remove the last user message from history for send (already added)
    if (history.isNotEmpty) history.removeLast();

    final reply = await gemini.chat(text, history, settings);
    await chat.addMessage('model', reply);

    setState(() => _isLoading = false);
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final chat = Provider.of<ChatService>(context);
    final settings = Provider.of<SettingsService>(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset('assets/images/logo.png', height: 28),
            const SizedBox(width: 8),
            const Text('WayyAi'),
          ],
        ),
        actions: [
          const ModeSelector(),
          IconButton(
            icon: const Icon(Icons.add_comment_outlined),
            tooltip: 'Obrolan Baru',
            onPressed: () async {
              await chat.createNewSession(mode: settings.mode);
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Image.asset('assets/images/logo.png', height: 36),
                    const SizedBox(width: 12),
                    const Text('WayyAi', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.add),
                title: const Text('Obrolan Baru'),
                onTap: () async {
                  Navigator.pop(context);
                  await chat.createNewSession(mode: settings.mode);
                },
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Riwayat Terkini', style: TextStyle(fontWeight: FontWeight.w600, color: Colors.grey)),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: chat.recentSessions.length,
                  itemBuilder: (context, i) {
                    final s = chat.recentSessions[i];
                    final selected = s.id == chat.currentSessionId;
                    return ListTile(
                      selected: selected,
                      leading: const Icon(Icons.chat_bubble_outline, size: 20),
                      title: Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(
                        '${s.messages.length} pesan • ${_formatDate(s.updatedAt)}',
                        style: const TextStyle(fontSize: 11),
                      ),
                      onTap: () {
                        chat.setCurrentSession(s.id);
                        Navigator.pop(context);
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, size: 18),
                        onPressed: () => chat.deleteSession(s.id),
                      ),
                    );
                  },
                ),
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.photo_library_outlined),
                title: const Text('Pustaka Gambar'),
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Fitur Pustaka Gambar segera hadir')),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.folder_outlined),
                title: const Text('Projek'),
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Fitur Projek segera hadir')),
                  );
                },
              ),
            ],
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: chat.currentSession == null || chat.currentSession!.messages.isEmpty
                ? _buildEmptyState(settings)
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    itemCount: chat.currentSession!.messages.length + (_isLoading ? 1 : 0),
                    itemBuilder: (context, i) {
                      if (_isLoading && i == chat.currentSession!.messages.length) {
                        return const Padding(
                          padding: EdgeInsets.all(16),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              ),
                              SizedBox(width: 12),
                              Text('WayyAi sedang berpikir...'),
                            ],
                          ),
                        );
                      }
                      final msg = chat.currentSession!.messages[i];
                      final isUser = msg.role == 'user';
                      return Align(
                        alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 6),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
                          decoration: BoxDecoration(
                            color: isUser
                                ? Theme.of(context).primaryColor
                                : (isDark ? const Color(0xFF1E1E1E) : Colors.grey[200]),
                            borderRadius: BorderRadius.only(
                              topLeft: const Radius.circular(16),
                              topRight: const Radius.circular(16),
                              bottomLeft: Radius.circular(isUser ? 16 : 4),
                              bottomRight: Radius.circular(isUser ? 4 : 16),
                            ),
                          ),
                          child: isUser
                              ? Text(msg.content, style: const TextStyle(color: Colors.white))
                              : MarkdownBody(
                                  data: msg.content,
                                  styleSheet: MarkdownStyleSheet(
                                    p: TextStyle(color: isDark ? Colors.white : Colors.black87),
                                    code: TextStyle(
                                      backgroundColor: isDark ? Colors.black : Colors.grey[300],
                                      fontFamily: 'monospace',
                                    ),
                                  ),
                                ),
                        ),
                      );
                    },
                  ),
          ),
          _buildInputBar(isDark),
        ],
      ),
    );
  }

  Widget _buildEmptyState(SettingsService settings) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/images/logo.png', height: 100),
            const SizedBox(height: 24),
            Text(
              'Halo, ${settings.userName.isEmpty ? "teman" : settings.userName}!',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'Mode saat ini: ${_modeLabel(settings.mode)}',
              style: TextStyle(color: Colors.grey[600]),
            ),
            const SizedBox(height: 24),
            const Text(
              'Mulai obrolan baru atau pilih dari riwayat di sebelah kiri.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  String _modeLabel(String mode) {
    switch (mode) {
      case 'kids':
        return 'Kids 👶';
      case 'worm':
        return 'Worm 🐛';
      default:
        return 'Human 🧑';
    }
  }

  Widget _buildInputBar(bool isDark) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF121212) : Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                maxLines: null,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                decoration: InputDecoration(
                  hintText: 'Tulis pesan...',
                  filled: true,
                  fillColor: isDark ? Colors.grey[900] : Colors.grey[100],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),
            ),
            const SizedBox(width: 8),
            CircleAvatar(
              backgroundColor: Theme.of(context).primaryColor,
              child: IconButton(
                icon: const Icon(Icons.send, color: Colors.white, size: 20),
                onPressed: _isLoading ? null : _send,
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    if (dt.day == now.day && dt.month == now.month && dt.year == now.year) {
      return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    }
    return '${dt.day}/${dt.month}';
  }
}
