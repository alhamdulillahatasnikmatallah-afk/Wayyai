import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'services/theme_service.dart';
import 'services/settings_service.dart';
import 'services/chat_service.dart';
import 'services/gemini_service.dart';
import 'screens/splash_screen.dart';
import 'screens/onboarding_screen.dart';
import 'screens/main_nav.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox('settings');
  await Hive.openBox('chats');
  await Hive.openBox('cache');

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeService()),
        ChangeNotifierProvider(create: (_) => SettingsService()),
        ChangeNotifierProvider(create: (_) => ChatService()),
        ChangeNotifierProvider(create: (_) => GeminiService()),
      ],
      child: const WayyAiApp(),
    ),
  );
}

class WayyAiApp extends StatelessWidget {
  const WayyAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer2<ThemeService, SettingsService>(
      builder: (context, themeService, settings, _) {
        return MaterialApp(
          title: 'WayyAi',
          debugShowCheckedModeBanner: false,
          theme: themeService.lightTheme,
          darkTheme: themeService.darkTheme,
          themeMode: themeService.isDark ? ThemeMode.dark : ThemeMode.light,
          home: FutureBuilder<bool>(
            future: settings.isOnboardingComplete(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SplashScreen();
              }
              if (snapshot.data == true) {
                return const MainNav();
              }
              return const OnboardingScreen();
            },
          ),
        );
      },
    );
  }
}
